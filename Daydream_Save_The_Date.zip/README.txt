Thank you for downloading the Daydream Save The Date Template!

How to Customize:
1. Open "index_daydream.html" in any text editor.
2. Replace [Your Names], [Wedding Date], and [Wedding Location] with your details.
3. Replace the photo in the "assets" folder (photo.jpg) with your own photo. Keep the filename the same.

Fonts Used:
- Great Vibes (for headings)
- Playfair Display (for important text)
- Poppins (for body text)
Fonts are already linked from Google Fonts.

How to Upload:
1. Zip all the files together (index_daydream.html, style_daydream.css, assets/photo.jpg).
2. Upload to your hosting platform (e.g., Vercel, Netlify, personal website, etc.).

Enjoy and congratulations on your special day! 💍✨
